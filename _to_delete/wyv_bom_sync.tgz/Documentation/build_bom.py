#!/usr/bin/env python3
"""Build Documentation/WYVERN_BOM.xlsx: the whole project's buy list on ONE sheet (rev 4).

Sections: Rocket | Wind Tunnel | Flow-Vis. Nothing has been bought yet, so every line is a purchase;
only filament and basic shop essentials (solder, wire, heat-shrink, glue, tape, 100 nF ceramics,
J-B Weld, RTV, hot glue) are assumed on hand. Items both builds use (servo 4-packs, angle gauge,
screw kit, heat-set inserts) are bought once, under Rocket.
Every line total and subtotal is a formula. Recalculate after building:
    python3 <xlsx skill>/scripts/recalc.py WYVERN_BOM.xlsx
"""
import os
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "WYVERN_BOM.xlsx")
F = Font(name="Arial", size=10); FB = Font(name="Arial", size=10, bold=True)
FH = Font(name="Arial", size=12, bold=True); BLUE = Font(name="Arial", size=10, color="0000FF")
HDR = PatternFill("solid", fgColor="1F2937"); HDRF = Font(name="Arial", size=10, bold=True, color="FFFFFF")
SEC = PatternFill("solid", fgColor="E5E7EB"); thin = Side(style="thin", color="D1D5DB")
COLS = ["Item", "Vendor", "Part # / Spec", "Link", "Why / where used", "Qty", "Unit ($)", "Line ($)", "Price source"]
WIDTH = [46, 13, 26, 46, 58, 6, 10, 11, 18]

CHK = "vendor 2026-11-02"
ROCKET = [
 ("Avionics", [
  ("Teensy 4.1 (no headers)", "SparkFun", "DEV-16771", "https://www.sparkfun.com/teensy-4-1.html", "Flight computer; its built-in microSD is the flight log. Leads soldered straight in. 1 flight + 1 spare", 2, 31.50, f"{CHK}, in stock"),
  ("Adafruit BNO085 9-DOF IMU, STEMMA QT", "Adafruit", "PID 4754", "https://www.adafruit.com/product/4754", "Attitude + rates, lowest board on the spine's +X face (Wire)", 1, 29.50, f"{CHK}, in stock"),
  ("Adafruit BMP388 barometric pressure / altimeter, STEMMA QT", "Adafruit", "PID 3966", "https://www.adafruit.com/product/3966", "Primary altimeter, 50 Hz (Wire1), spine -Y", 1, 9.95, f"{CHK}, in stock"),
  ("Adafruit BME688 temperature / humidity / pressure, STEMMA QT", "Adafruit", "PID 5046", "https://www.adafruit.com/product/5046", "Pad temperature + humidity for measured air density (Wire2), spine -Y", 1, 19.95, "vendor 2026-11-01, in stock"),
  ("STEMMA QT to male header cable 150 mm", "Adafruit", "PID 4209", "https://www.adafruit.com/product/4209", "One per sensor onto its Teensy I2C bus + 1 spare", 4, 0.95, "vendor 2026-10-16, in stock"),
  ("Tactile button switch 6 mm, 20-pack", "Adafruit", "PID 367", "https://www.adafruit.com/product/367", "Arm button in the -Y wall cradle", 1, 2.50, f"{CHK}, in stock"),
  ("LED - Basic Red 3 mm", "SparkFun", "COM-00533", "https://www.sparkfun.com/led-basic-red-3mm.html", "Arm / state LED beside the button; 1 + spare", 2, 0.50, f"{CHK}, in stock"),
  ("SanDisk Ultra 32 GB microSDHC, UHS-I / Class 10", "Amazon", "B00M55C0NS", "https://www.amazon.com/dp/B00M55C0NS", "Flight log card in the Teensy socket; soak-test it with t3_arm_log before flying", 1, 18.19, f"{CHK}, in stock"),
  ("SparkFun Solder-able Breadboard (full)", "SparkFun", "PRT-12070", "https://www.sparkfun.com/sparkfun-solder-able-breadboard.html", "Power board cut to 16 x 62 mm on the spine's +Y face (2 bucks, divider, 470 uF)", 1, 6.95, "vendor 2026-10-16, in stock"),
 ]),
 ("Actuation", [
  ("EMAX ES9251 II digital micro servo, 4-pack", "Amazon", "B0DLKJ3MJJ", "https://www.amazon.com/dp/B0DLKJ3MJJ", "18.0 x 7.9 x 16.8 mm, 4 g, 4.5-6.0 V. 4 control fins + 1 for the tunnel cradle + 3 spares (plastic gears)", 2, 28.60, "vendor 2026-11-02, only 5 left"),
  ("GemRed DAG-V1 digital angle gauge", "Amazon", "B00WQLHG2G", "https://www.amazon.com/dp/B00WQLHG2G", "Servo trim and us/deg calibration (t2); also the tunnel's deflection check", 1, 19.99, "vendor 2026-10-22, in stock"),
 ]),
 ("Power", [
  ("OVONIC 2S 450 mAh 100C LiPo, XT30, 2-pack", "Amazon", "B0D3F5SQ5T", "https://www.amazon.com/dp/B0D3F5SQ5T", "Flight battery + spare (4.2x margin on the 26 min mission). HV-rated: charge to 8.40 V anyway", 1, 20.37, f"{CHK}, in stock"),
  ("OVONIC D15 dual LiPo charger, 1S-3S, 1.2 A", "Amazon", "B0G6CMG9GW", "https://www.amazon.com/dp/B0G6CMG9GW", "Balance-charges the 2S packs", 1, 22.99, f"{CHK}, in stock"),
  ("Adafruit MPM3610 5 V buck, 6-21 V in, 1.2 A", "Adafruit", "PID 4739", "https://www.adafruit.com/product/4739", "One for the Teensy VIN, one for the servo rail, 1 spare", 3, 6.95, "vendor 2026-10-22, in stock"),
  ("Pololu Mini MOSFET slide switch LV", "Pololu", "#2810", "https://www.pololu.com/product/2810", "Main power switch in the +Y wall cradle; 1 + spare. No Adafruit / SparkFun part carries 3 A with reverse protection at this size", 2, 4.49, "vendor 2026-10-16"),
  ("Amass XT30 male + female pigtails, 16 AWG, 100 mm", "Amazon", "B0F44KMCWT", "https://www.amazon.com/dp/B0F44KMCWT", "Battery lead to the 2810", 1, 8.99, "vendor 2026-11-01, in stock"),
  ("470 uF 10 V low-ESR electrolytic, 6 x 12 mm, 10-pack", "Amazon", "B0D78SV1J2", "https://www.amazon.com/dp/B0D78SV1J2", "Servo-rail bulk capacitor under the perfboard (6 x 12 mm fits the 9 mm pillar gap laid flat)", 1, 3.99, f"{CHK}"),
  ("BOJACK 1 % metal-film resistor kit, 50 values, 1350 pcs", "Amazon", "B07P3MFG5D", "https://www.amazon.com/dp/B07P3MFG5D", "100k / 47k battery divider, 220 ohm LED resistor", 1, 12.99, f"{CHK}"),
 ]),
 ("Propulsion", [
  ("AeroTech Econojet F42-4T single-use 29 x 83 mm, 2-pack", "eRockets", "AER 64204, 4 s delay", "https://www.erockets.biz/aerotech-29mm-composite-model-rocket-motor-single-use-f42-4t-2pk-aer-64204-required-to-pay-for-ups-ground-shipping/", "3 research flights + 1 spare. Not sold by Adafruit / SparkFun / Amazon; UPS ground, continental US", 2, 49.49, "vendor 2026-10-16, stock 4"),
 ]),
 ("Recovery", [
  ("Estes 302271 24 in parachute", "Amazon", "B0006NAQ6E", "https://www.amazon.com/dp/B0006NAQ6E", "Main chute, ~6.3 m/s descent at 758 g", 1, 10.79, f"{CHK}, only 1 left"),
  ("9KM DWLIFE braided Kevlar cord", "Amazon", "B0B1WKH21R", "https://www.amazon.com/dp/B0B1WKH21R", "Shock cord, 19 ft tied to the printed anchor. Pick a 300-500 lb option at least 20 ft long (price shown is the listing's default option)", 1, 5.72, f"{CHK}"),
  ("Fruity Chutes 10 in Nomex blanket (NB-10, for 2.6 in airframes)", "Fruity Chutes", "NB-10", "https://shop.fruitychutes.com/products/10-nomex-blanket-2-6-airframe", "Wraps the chute in the 55 mm bay. No Amazon / Adafruit / SparkFun equivalent sized for rocketry", 1, 16.45, f"{CHK}, 11 left"),
 ]),
 ("Hardware", [
  ("Mywish M2-M5 304 stainless screw kit, 1290 pcs", "Amazon", "B0CQWYFTXC", "https://www.amazon.com/dp/B0CQWYFTXC", "Board screws, servo ears, joints, retainer, hubs; tunnel M3 / M5 too", 1, 17.99, "vendor 2026-10-22, in stock"),
  ("Heat-set insert kit M2-M6, 400 pcs", "Amazon", "B0CLKDPN65", "https://www.amazon.com/dp/B0CLKDPN65", "M2 / M3 inserts in the airframe; tunnel M5 junction rings and M2.5 window tabs", 1, 15.97, "vendor 2026-11-01, in stock"),
 ]),
 ("Launch equipment (skip if your club launch provides a 1010 rail and controller)", [
  ("Estes Pro Series II launch rail system, 6 ft, 1010", "Amazon", "B0F76JWDQZ", "https://www.amazon.com/dp/B0F76JWDQZ", "The 6 ft 1010 rail the sims assume (15.0 m/s rail exit); two 3 ft sections, blast plate, adjustable angle", 1, 179.79, f"{CHK}, in stock"),
  ("Estes 2240 Pro Series II launch controller", "Amazon", "B00FU4AX44", "https://www.amazon.com/dp/B00FU4AX44", "Remote ignition from the safe distance", 1, 42.77, f"{CHK}, in stock"),
 ]),
]
TUNNEL = [
 ("Airflow", [
  ("6 in inline duct fan, 405 CFM, EC motor, 0-100 % speed controller", "Amazon", "B08JZM1KHX", "https://www.amazon.com/dp/B08JZM1KHX", "Tunnel drive on the printed 100 sq -> 6 in transition", 1, 64.99, "vendor 2026-11-01, only 3 left"),
  ("AC Infinity stainless duct clamps 6 in, 2-pack", "Amazon", "B07L4S62Q6", "https://www.amazon.com/dp/B07L4S62Q6", "Clamps the transition socket onto the fan collar", 1, 7.99, "vendor 2026-11-01"),
  ("40 mesh 304 stainless woven mesh, 2 x 31 x 115 cm", "Amazon", "B0BBMTDK88", "https://www.amazon.com/dp/B0BBMTDK88", "Coarse turbulence screen, laid into Jerrod's screen frame at the print pause", 1, 15.99, "vendor 2026-11-01, only 1 left"),
  ("80 mesh 304 stainless woven mesh, 5 x 20 x 30 cm", "Amazon", "B09VNKDS9R", "https://www.amazon.com/dp/B09VNKDS9R", "Fine turbulence screen (second frame)", 1, 7.99, "vendor 2026-11-01, in stock"),
 ]),
 ("Balance (fin force)", [
  ("Mini load cell 100 g, straight bar (TAL221)", "SparkFun", "SEN-14727", "https://www.sparkfun.com/mini-load-cell-100g-straight-bar-tal221.html", "Two under the servo cradle, 60 mm apart: normal force (sum) and chordwise CP (difference)", 2, 14.50, "vendor 2026-11-01, in stock"),
  ("SparkFun Load Cell Amplifier - HX711", "SparkFun", "SEN-13879", "https://www.sparkfun.com/sparkfun-load-cell-amplifier-hx711.html", "One per TAL221, gain 128, VCC and VDD to the Metro's 3.3 V", 2, 4.95, "vendor 2026-11-01, in stock"),
  ("Bekith precision calibration weights, 10 mg-100 g, 17 pcs", "Amazon", "B07K7F7D8K", "https://www.amazon.com/dp/B07K7F7D8K", "Thread-and-pulley calibration of both cells (stay under 100 g)", 1, 8.99, "vendor 2026-11-01, in stock"),
  ("uxcell MR105ZZ bearings 5 x 10 x 4 mm, 10 pcs", "Amazon", "B0DP7FYPDV", "https://www.amazon.com/dp/B0DP7FYPDV", "Presses into the printed calibration pulley wheel", 1, 8.39, "vendor 2026-11-01, only 15 left"),
 ]),
 ("Controller and wiring (the servo comes from the Rocket 4-packs)", [
  ("Adafruit Metro M4 feat. Microchip ATSAMD51", "Adafruit", "PID 3382", "https://www.adafruit.com/product/3382", "Tunnel controller (wt_balance_daq v3.0, Arduino IDE): servo, both HX711s, BME688", 1, 27.50, "vendor 2026-11-01, 17 in stock"),
  ("Adafruit BME688 temperature / humidity / pressure, STEMMA QT", "Adafruit", "PID 5046", "https://www.adafruit.com/product/5046", "Room air density for q (a second unit; the flight one stays in the rocket)", 1, 19.95, "vendor 2026-11-01, in stock"),
  ("STEMMA QT to male header cable 150 mm", "Adafruit", "PID 4209", "https://www.adafruit.com/product/4209", "BME688 to the Metro's SDA / SCL header", 1, 0.95, "vendor 2026-10-16, in stock"),
  ("Female DC power adapter, 2.1 mm jack to screw terminal", "Adafruit", "PID 368", "https://www.adafruit.com/product/368", "Breaks the 5 V supply out to the servo lead and the Metro GND", 1, 2.00, "vendor 2026-11-02, in stock"),
  ("5 V 3 A wall power supply, 5.5 x 2.1 mm plug, UL listed", "Amazon", "B09JW38H3X", "https://www.amazon.com/dp/B09JW38H3X", "Servo power (4.5-6 V servo, no LiPo in the tunnel)", 1, 8.95, "vendor 2026-11-02"),
  ("JR servo extension leads 30 cm, 10-pack", "Amazon", "B07NJB58XC", "https://www.amazon.com/dp/B07NJB58XC", "Cradle servo to the Metro; cut one to break out servo power", 1, 8.99, "vendor 2026-11-01"),
  ("ELEGOO Dupont jumper wires, 120 pcs", "Amazon", "B01EV70C78", "https://www.amazon.com/dp/B01EV70C78", "HX711s and BME688 to the Metro headers", 1, 6.98, "vendor 2026-11-01"),
 ]),
 ("Airspeed and test section", [
  ("Jadeshay differential pitot tube kit with silicone hose", "Amazon", "B07Q6126B6", "https://www.amazon.com/dp/B07Q6126B6", "Total + static ports upstream of the fin, to the printed inclined manometer", 1, 10.39, "vendor 2026-11-01, only 9 left"),
  ("DERNORD clear PVC tubing 1/8 in ID x 1/4 in OD, 25 ft", "Amazon", "B0D2CR3322", "https://www.amazon.com/dp/B0D2CR3322", "Manometer leg in the 1:10 ramp + pitot lines", 1, 9.99, "vendor 2026-11-01, in stock"),
  ("Clear acrylic sheet 3 mm, 12 x 12 in, 5-pack", "Amazon", "B0GY1GB12W", "https://www.amazon.com/dp/B0GY1GB12W", "Test-section windows to watch the tufts", 1, 18.99, "vendor 2026-11-01, in stock"),
 ]),
]
OPTIONAL_VIS = [
 ("Smoke + laser sheet (optional: tufts already cover the RQ data)", [
  ("COLBOR CF3 30 W portable fog machine", "Amazon", "B0FW4VQ72H", "https://www.amazon.com/dp/B0FW4VQ72H", "Smoke source for Jerrod's rake", 1, 89.00, "your link, 2026-10-21"),
  ("COLBOR fog fluid for CF3 / CF5 (2 fl oz x 4)", "Arts Cameras", "COLBOR CF fluid", "https://artscameras.com/products/colbor-fluid-for-cf3-cf5-fog-machine-2-fl-oz-4-pack", "Only if the CF3 box has none", 1, 25.90, "vendor 2026-10-21"),
  ("520 nm focusable green line laser module", "Amazon", "B0CKP4SYL7", "https://www.amazon.com/dp/B0CKP4SYL7", "Laser sheet on the X/Y gantry", 1, 39.00, "your link"),
  ("SmallRig P96L RGB video light", "Amazon", "B09G98NRQZ", "https://www.amazon.com/dp/B09G98NRQZ", "LED ceiling module; any lamp works for tufts", 1, 30.60, "your link"),
  ("Loc-Line 40413 hose sample kit (1/4 in)", "Amazon", "B0GZL8N636", "https://www.amazon.com/dp/B0GZL8N636", "Smoke wand plumbing", 1, 25.00, "your link"),
  ("Magnets 6 x 2 mm (250) and 10 x 3 mm (50)", "Amazon", "B0DBVJF1G2 / B0BVY5VYQY", "https://www.amazon.com/dp/B0DBVJF1G2", "Only Jerrod's smoke-rake ports and Gridfinity floor use them; Phase A uses the wall panel", 2, 9.99, "your links"),
 ]),
]
ON_HAND = [
 ("Raspberry Pi Pico 2 W", 2, "Spares (the tunnel now runs on a Metro M4)"),
 ("Adafruit BNO085 (4754)", 4, "1 flight IMU on the spine's +X face; spares"),
 ("Adafruit BME688 (5046)", 2, "Flight baro + the spare logs air density in the tunnel"),
 ("microSD 32 GB cards (+ the 254 breakout, now spare)", 1, "Rev 4: the card goes in the Teensy 4.1's own socket; soak-test it with t3_arm_log before flying"),
 ("OVONIC 2S 450 mAh LiPo (XT30)", 2, "Flight battery (4.2x margin on the 26-min mission with the Teensy, rev 4; 2.3 h pad hold)"),
 ("2S/3S balance charger", 1, "Charging"),
 ("470 uF low-ESR + 100 nF; 100k/47k 1 % and 220 ohm resistors", 1, "Servo bulk cap, Vbat divider, arm-LED resistor"),
 ("Adafruit PCA9548 I2C mux (5626)", 1, "Spare (the tunnel now reads HX711s, which need no mux)"),
 ("STEMMA QT 300 mm cables (5384)", 6, "Spares (rev 4 has no QT-to-QT runs)"),
 ("Estes Pro Series II launch rail (6 ft) + controller", 1, "Launch system (stated on hand)"),
 ("Adafruit load cells 1 kg x2, 5 kg x2; HX711 x4; calibration weights", 1, "2 HX711 + the weights run the tunnel balance (with 2 new 100 g TAL221s; the 1 kg cells are too coarse for 1-5 g fin loads)"),
 ("Filament: PC-FR, PETG-CF, ASA (black), ASA-Aero, PLA", 1, "Plenum/MMT/retainer (PC-FR), fins/hubs/deck (PETG-CF), tubes (ASA-Aero)"),
 ("Heat-set insert kit M2-M6, J-B Weld, Kapton, 24 AWG silicone wire, heat-shrink, headers", 1, "Assembly"),
 ("Nomex chute protector 12x12 in", 1, "Recovery bay"),
 ("Estes 24 in rip-stop chute, aramid shock cord 19 ft", 1, "VERIFY these arrived (they were on the TVC cart)"),
 ("Jerrod H tunnel STLs (Wind Tunnel/STEM+Tunnel+Promo+-+0.4n_stls)", 1, "Tunnel hardware is listed on the Wind Tunnel sheets"),
 ("Mechatronics MS1238 120 mm fan", 1, "Spare; not used (the 8 in duct fan replaces it)"),
]
RETIRED = [
 ("Feather RP2040 RFM95 x3, ADXL375, ground-station Feather, 915 MHz whips", "Rev 3 avionics; rev 4 runs on a Teensy 4.1 with no radio and no high-g accelerometer (never bought)"),
 ("EMAX ES08MA II servos", "TVC gimbal; too tall for the single servo ring (needs <= 17 mm body height around the central bypass)"),
 ("MR105-2RS bearings, M2 rod-end ball links", "TVC gimbal linkage"),
 ("Electromagnets (TOMSHIELE, AIRTAK), N52 magnets, IRF520, 1N4007, 12 V PSU", "Magnetic TVC stand"),
 ("TMAG5273 Hall sensor, Arduino Nano", "Magnetic-gimbal sensing / solenoid DAQ"),
 ("VL53L4CD ToF x6", "Unused in both revisions"),
 ("301 SS foil", "TVC balance flexures"),
]


COLS = ["Item", "Vendor", "Part # / Spec", "Link", "Why / where used", "Qty", "Unit ($)", "Line ($)", "Price source"]
TOP = PatternFill("solid", fgColor="374151"); TOPF = Font(name="Arial", size=11, bold=True, color="FFFFFF")

wb = Workbook(); ws = wb.active; ws.title = "BOM"
ws["A1"] = "GTR70E WYVERN — bill of materials (rev 4)"; ws["A1"].font = FH
ws["A2"] = ("Nothing bought yet: every line is a purchase. Assumed on hand: filament and basic shop essentials (solder, wire, heat-shrink, "
            "glue, tape, 100 nF ceramics, J-B Weld, RTV). Shared items are bought once under Rocket. Nose ballast (239 g) is any dense scrap in epoxy.")
ws["A2"].font = Font(name="Arial", size=9, italic=True, color="4B5563")
for i, (c, w) in enumerate(zip(COLS, WIDTH), 1):
    cell = ws.cell(row=4, column=i, value=c); cell.font = HDRF; cell.fill = HDR
    ws.column_dimensions[get_column_letter(i)].width = w
ws.freeze_panes = "A5"
r = 5; totals = {}
for top, sections in (("ROCKET", ROCKET), ("WIND TUNNEL", TUNNEL), ("FLOW-VIS", OPTIONAL_VIS)):
    ws.cell(row=r, column=1, value=top).font = TOPF
    for c in range(1, 10): ws.cell(row=r, column=c).fill = TOP
    r += 1; subs = []
    for name, items in sections:
        ws.cell(row=r, column=1, value=name).font = FB
        for c in range(1, 10): ws.cell(row=r, column=c).fill = SEC
        r += 1; first = r
        for (item, vend, part, link, why, qty, unit, src) in items:
            vals = [item, vend, part, link, why, qty, unit, f"=F{r}*G{r}", src]
            for c, v in enumerate(vals, 1):
                cell = ws.cell(row=r, column=c, value=v); cell.font = F
                cell.alignment = Alignment(wrap_text=c in (1, 5), vertical="top")
            ws.cell(row=r, column=6).font = BLUE; ws.cell(row=r, column=7).font = BLUE
            ws.cell(row=r, column=7).number_format = "$#,##0.00"; ws.cell(row=r, column=8).number_format = "$#,##0.00"
            if link: ws.cell(row=r, column=4).hyperlink = link
            r += 1
        ws.cell(row=r, column=7, value="Subtotal").font = F
        c = ws.cell(row=r, column=8, value=f"=SUM(H{first}:H{r-1})"); c.font = F; c.number_format = "$#,##0.00"
        subs.append(f"H{r}"); r += 1
    ws.cell(row=r, column=7, value=f"{top.title()} total").font = FB
    c = ws.cell(row=r, column=8, value="=" + "+".join(subs)); c.font = FB; c.number_format = "$#,##0.00"
    totals[top] = f"H{r}"; r += 2
summary = [("Rocket", f"={totals['ROCKET']}"), ("Wind Tunnel", f"={totals['WIND TUNNEL']}"), ("Flow-Vis", f"={totals['FLOW-VIS']}"),
           ("Rocket + Wind Tunnel", f"={totals['ROCKET']}+{totals['WIND TUNNEL']}"),
           ("Everything (incl. Flow-Vis)", f"={totals['ROCKET']}+{totals['WIND TUNNEL']}+{totals['FLOW-VIS']}")]
ws.cell(row=r, column=1, value="SUMMARY").font = TOPF
for c in range(1, 10): ws.cell(row=r, column=c).fill = TOP
r += 1
for a, f in summary:
    ws.cell(row=r, column=7, value=a).font = FB if "+" in a or "Every" in a else F
    c = ws.cell(row=r, column=8, value=f); c.font = FB if "+" in a or "Every" in a else F; c.number_format = "$#,##0.00"
    r += 1
r += 1
ws.cell(row=r, column=1, value="Blue = inputs (qty, unit price); line, subtotals and totals are formulas. Stores: Adafruit, SparkFun, Amazon, except the 2810 (Pololu), motors (eRockets) and the Nomex blanket (Fruity Chutes); fog fluid only if the CF3 ships without it.").font = Font(name="Arial", size=9, italic=True)
wb.save(OUT); print("wrote", OUT)
